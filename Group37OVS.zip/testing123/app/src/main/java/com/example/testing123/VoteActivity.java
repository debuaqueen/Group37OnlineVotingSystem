package com.example.testing123;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class VoteActivity extends AppCompatActivity {

    private Button voteOption1, voteOption2;
    FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vote);

        db = FirebaseFirestore.getInstance();

        voteOption1 = findViewById(R.id.vote_option1);
        voteOption2 = findViewById(R.id.vote_option2);

        voteOption1.setOnClickListener(view -> vote("Option 1"));
        voteOption2.setOnClickListener(view -> vote("Option 2"));
    }

    void vote(String option) {
        Map<String, Object> voteData = new HashMap<>();
        voteData.put("option", option);

        db.collection("votes").add(voteData)
                .addOnSuccessListener(documentReference ->
                        Toast.makeText(VoteActivity.this, "Vote recorded!", Toast.LENGTH_SHORT).show())
                .addOnFailureListener(e ->
                        Toast.makeText(VoteActivity.this, "Error recording vote: " + e.getMessage(), Toast.LENGTH_SHORT).show());
    }
}
